﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PPOL;

namespace PPOL.Properties
{
    public partial class UserControlSettings : UserControl
    {
        public UserControlSettings()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void UserControlSettings_Load(object sender, EventArgs e)
        {

        }
        public void Apply()
        {
            
                // Save Settings
                SaveSettings();

              
        }

        private void SaveSettings()
        {
            Properties.Settings settings = new Properties.Settings();
            settings.PPOLURL = this.txtURL.Text;
            settings.Account = this.txtAccount.Text;
            settings.UserName = this.txtUserName.Text;
            settings.Password = this.txtPassword.Text;
            settings.Save();
        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            try
            {
                DomainService.DomainLocationAPIService local = new DomainService.DomainLocationAPIService();
                local.Url = "http://www.planplusonline08.com/cxf/DomainLocationAPI";
                string serverURL = local.lookupServerURL(this.txtAccount.Text, this.txtUserName.Text, this.txtPassword.Text);
                this.txtURL.Text = serverURL;
            }
            catch (Exception ex)
            {
                ClassFactory.Instance.Show(ex);
            }

        }
    }
}
